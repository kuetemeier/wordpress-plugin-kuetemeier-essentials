=== Kuetemeier Essentials ===
Contributors: Jörg Kütemeier
Donate link:
Tags: test, data, privacy, speed, optimiziation, optimize, data, quick, fast, data-privacy
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 4.9
Tested up to: 4.9.5

WordPress PlugIn with essential extensions for speed, data privacy and optimization.

== Description ==

WordPress PlugIn with essential extensions for speed, data privacy and optimization.

== Installation ==

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.7.1-beta =
- Add german translation

= 0.7.0-beta =
- First public Beta

= 0.1 =
- Initial Revision
