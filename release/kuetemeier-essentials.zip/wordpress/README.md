# php-kuetemeier-wordpress
Description: A Collection of PHP class for WordPress Plugin Development

Version: 1.0.1  
Latest Stable Version: 1.0.1

License: Apache-2.0

## Development and Contribution

Hints, corrections and Pull requests welcome. For development notes and crontribution details, please see [CONTRIBUTE.md](https://github.com/kuetemeier/php-kuetemeier-collection/blob/master/CONTRIBUTE.md).
