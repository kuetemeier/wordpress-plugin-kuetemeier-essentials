=== Kuetemeier Essentials ===
Contributors: Jörg Kütemeier
Donate link:
Tags:
License: 
License URI: 
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 0.1

Essential and fast addons for WordPress websites

== Description ==

Essential and fast addons for WordPress websites

== Installation ==

For development:

Install composer: https://getcomposer.org/doc/00-intro.md


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1 =
- Initial Revision
