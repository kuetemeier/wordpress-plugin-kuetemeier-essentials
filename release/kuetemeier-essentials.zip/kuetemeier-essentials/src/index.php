<?php // a black hole... for a litte bit more security.
