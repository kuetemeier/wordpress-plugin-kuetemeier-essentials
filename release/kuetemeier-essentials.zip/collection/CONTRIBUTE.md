# Contribute to this project

## Prepare for development

```
    npm update
    composer update

    gulp watch
```
